Arte y técnica de escribir con procedimientos o claves secretas o de un modo enigmático, de tal forma que lo escrito solamente sea inteligible para quien sepa descifrarlo.

En castellano son sinónimos cifrar y encriptar, así como las acciones inversas descifrar y desencriptar.